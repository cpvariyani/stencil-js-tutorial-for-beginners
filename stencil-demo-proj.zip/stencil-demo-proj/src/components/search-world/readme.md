# search-world



<!-- Auto Generated Below -->


## Properties

| Property     | Attribute     | Description | Type     | Default     |
| ------------ | ------------- | ----------- | -------- | ----------- |
| `searchText` | `search-text` |             | `string` | `undefined` |


## Events

| Event                     | Description | Type                  |
| ------------------------- | ----------- | --------------------- |
| `searchWorldNameSelected` |             | `CustomEvent<string>` |


----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
